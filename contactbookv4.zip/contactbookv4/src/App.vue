<script setup>
import { RouterView } from 'vue-router'
</script>

<template>
  <main>
    <RouterView />
  </main>
</template>

<style scoped>

*{
  font-family: sans-serif;
}

main{
  max-width: 1140px;
  margin: 0 auto;
}

</style>