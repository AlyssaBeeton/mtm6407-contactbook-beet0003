<script setup>

import Header from '@/components/Header.vue'

</script>

<template>
    <Header />
    <h2>Contact Page</h2>

</template>

<style scoped>

</style>